﻿document.addEventListener("DOMContentLoaded", function () {
    const registerButton = document.getElementById("registerButton");
    const modal = document.getElementById("myModal");
    const span = document.getElementsByClassName("close")[0];
    const clickCounter = document.getElementById("clickCounter");
    let clickCount = parseInt(localStorage.getItem('clickCount')) || 0;

    // Atualiza o contador na tela
    clickCounter.textContent = `Número de cliques: ${clickCount}`;

    //diminui o volume da música
    backgroundMusic.volume = 0.03;

    registerButton.onclick = function () {
        // Verifica se todos os campos obrigatórios estão preenchidos
        if (validateFields()) {
            modal.style.display = "block";
            clickCount++;
            localStorage.setItem('clickCount', clickCount);
            clickCounter.textContent = `Número de cliques: ${clickCount}`;
        } else {
            alert("Por favor, preencha todos os campos obrigatórios.");
        }
    };

    span.onclick = function () {
        modal.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };

    // Função para validar os campos
    function validateFields() {

        const requiredFields = document.querySelectorAll('input[required]');
        
        for (let i = 0; i < requiredFields.length; i++) {
            if (!requiredFields[i].value.trim()) {
                return false;
            }
        }
        return true;
    }

   



});
