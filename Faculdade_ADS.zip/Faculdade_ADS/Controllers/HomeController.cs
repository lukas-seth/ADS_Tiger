﻿using Microsoft.AspNetCore.Mvc;

namespace Faculdade_ADS.Controllers
{
    public class HomeController : Controller
    {
        private static int clickCount = 0;

        public IActionResult Index()
        {
            ViewBag.ClickCount = clickCount;
            return View();
        }

        [HttpPost]
        public IActionResult Register()
        {
            clickCount++;
            return Json(new { clickCount });
        }
    }
}
